<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="This is the Electronic Document Flow dashboard." />
    <meta name="author" content="Patiphan Chaloemnon" />
    <title>จัดการผู้ใช้</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
    <?php include_once 'template/navbar.php'; ?>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <?php include_once 'template/sidebar.php'; ?>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">จัดการผู้ใช้</h1>                     
                        <div class="card-body">
                            <table id="datatablesSimple">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Username</th>
                                        <th>อีเมล</th>
                                        <th>ชื่อเต็ม</th>
                                        <th>ฝ่าย</th>
                                        <th>แผนก</th>
                                        <th>ตำแหน่ง</th>
                                        <th>สิทธิ</th>
                                        <th>สถานะ</th>
                                        <th>การดำเนินการ</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>Id</th>
                                        <th>Username</th>
                                        <th>อีเมล</th>
                                        <th>ชื่อเต็ม</th>
                                        <th>ฝ่าย</th>
                                        <th>แผนก</th>
                                        <th>ตำแหน่ง</th>
                                        <th>สิทธิ</th>
                                        <th>สถานะ</th>
                                        <th>การดำเนินการ</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Kaitom.k</td>
                                        <td>Kaitom.k@gmail.com</td>
                                        <td>Kaitom Kaboom</td>
                                        <td>1</td>
                                        <td>2</td>
                                        <td>3</td>
                                        <td>User</td>
                                        <td>Active</td>
                                        <td>
                                            <a href="users-config/edit_user.php?id=1" class="btn btn-warning"><i class="fas fa-edit"></i></a>
                                            <a href="users-config/delete_user.php?id=1" class="btn btn-danger" onclick="return confirm('ยืนยัน การลบผู้ใช้หรือไม่?');"><i class="fas fa-trash-alt"></i></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Mootom.M</td>
                                        <td>Mootom.M@gmail.com</td>
                                        <td>Kaitom Mamboo</td>
                                        <td>2</td>
   
                                        <td>1</td>
                                        <td>3</td>
                                        <td>User</td>
                                        <td>Inactive</td>
                                        <td>
                                            <a href="users-config/edit_user.php?id=2" class="btn btn-warning"><i class="fas fa-edit"></i></a>
                                            <a href="users-config/delete_user.php?id=2" class="btn btn-danger" onclick="return confirm('ยืนยัน การลบผู้ใช้หรือไม่?');"><i class="fas fa-trash-alt"></i></a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    
                </div>
            </main>
            <?php include_once 'template/footer.php'; ?>
        </div>
    </div>
    <?php include_once 'config/modules.php'; ?>
</body>
</html>
