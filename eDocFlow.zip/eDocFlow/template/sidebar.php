<nav class="sb-sidenav accordion sb-sidenav-light" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <!-- Document Section -->
                            <div class="sb-sidenav-menu-heading">Document</div>
                            <a class="nav-link" href="inbox.php" >
                                <div class="sb-nav-link-icon"><i class="fas fa-inbox"></i></div>
                                เอกสารขาเข้า
                            </a>
                            <a class="nav-link" href="outbox.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-paper-plane"></i></div>
                                เอกสารขาออก
                            </a>
                
                            <!-- Admin Section -->
                            <div class="sb-sidenav-menu-heading">Admin</div>
                            <a class="nav-link" href="dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                แดชบอร์ด
                            </a>
                            <a class="nav-link" href="users.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                                จัดการผู้ใช้งาน
                            </a>
                            <a class="nav-link" href="settings.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-cogs"></i></div>
                                ตั่งค่า
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        Username
                    </div>
                </nav>