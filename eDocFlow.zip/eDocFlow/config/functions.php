<?php include_once 'config/modules.php'; ?>
<?php include_once 'template/footer.php'; ?>
<?php include_once 'template/sidebar.php'; ?>